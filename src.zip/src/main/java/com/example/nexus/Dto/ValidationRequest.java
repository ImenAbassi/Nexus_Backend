package com.example.nexus.Dto;

public class ValidationRequest {
    private String etat;

    // Getters et setters
    public String getEtat() {
        return etat;
    }

    public void setEtat(String etat) {
        this.etat = etat;
    }
}
