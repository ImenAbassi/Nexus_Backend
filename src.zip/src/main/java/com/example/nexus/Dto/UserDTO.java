package com.example.nexus.Dto;



public class UserDTO {

    private Long idUser;

    private String prenom;

    private String nom;

    private String cin;

    private String adresseMailPro;

    

    public UserDTO() {
    }

    public Long getIdUser() {
        return idUser;
    }

    public void setIdUser(Long idUser) {
        this.idUser = idUser;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getCin() {
        return cin;
    }

    public void setCin(String cin) {
        this.cin = cin;
    }

    public String getAdresseMailPro() {
        return adresseMailPro;
    }

    public void setAdresseMailPro(String adresseMailPro) {
        this.adresseMailPro = adresseMailPro;
    }







 

}
