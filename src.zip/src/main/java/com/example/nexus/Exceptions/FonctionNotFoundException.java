package com.example.nexus.Exceptions;


public class FonctionNotFoundException extends RuntimeException {
    public FonctionNotFoundException(String message) {
        super(message);
    }
}

