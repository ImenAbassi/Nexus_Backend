package com.example.nexus.Exceptions;

public class SocieteNotFoundException extends RuntimeException {
    public SocieteNotFoundException(String message) {
        super(message);
    }
}
