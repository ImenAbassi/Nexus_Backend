package com.example.nexus.Repository;

import com.example.nexus.Entitie.ContactRH;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContactRHRepository extends JpaRepository<ContactRH, Long> {
}
