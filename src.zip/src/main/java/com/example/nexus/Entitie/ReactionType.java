package com.example.nexus.Entitie;

public enum ReactionType {
    LIKE,
    LOVE,
    HAHA,
    WOW,
    SAD,
    ANGRY
}
