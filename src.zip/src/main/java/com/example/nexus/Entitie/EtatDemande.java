package com.example.nexus.Entitie;

public enum EtatDemande {
    EN_ATTENTE, 
    APPROUVEE,
    REJETEE;
}
