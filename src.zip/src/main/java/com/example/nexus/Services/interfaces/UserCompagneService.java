package com.example.nexus.Services.interfaces;

import com.example.nexus.Entitie.UserCompagne;
import com.example.nexus.Services.general.CRUDService;

public interface UserCompagneService extends CRUDService<UserCompagne> {

}