package com.example.nexus.Services.interfaces;

import com.example.nexus.Entitie.Role;
import com.example.nexus.Services.general.CRUDService;

public interface RoleService extends CRUDService<Role> {

}