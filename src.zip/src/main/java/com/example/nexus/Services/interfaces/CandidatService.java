package com.example.nexus.Services.interfaces;

import com.example.nexus.Entitie.Candidat;
import com.example.nexus.Services.general.CRUDService;

public interface CandidatService extends CRUDService<Candidat> {
    
}
