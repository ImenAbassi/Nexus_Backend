package com.example.nexus.Services;

import com.example.nexus.Entitie.Pointage;
import com.example.nexus.Repository.PointageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class PointageService {

    @Autowired
    private PointageRepository pointageRepository;

    // Récupérer tous les pointages
    public List<Pointage> getAllPointages() {
        return pointageRepository.findAll();
    }

    // Récupérer les pointages par date
    public List<Pointage> getPointagesByDate(LocalDate date) {
        return pointageRepository.findByDatePointage(date);
    }

    // Récupérer un pointage par son ID
    public Pointage getPointageById(Long id) {
        Optional<Pointage> pointage = pointageRepository.findById(id);
        return pointage.orElseThrow(() -> new RuntimeException("Pointage non trouvé"));
    }

    // Créer un nouveau pointage
    public Pointage createPointage(Pointage pointage) {
        pointage.calculerHeuresTravaillees(); // Calculer les heures travaillées avant de sauvegarder
        return pointageRepository.save(pointage);
    }

    // Mettre à jour un pointage existant
    public Pointage updatePointage(Long id, Pointage pointageDetails) {
        Pointage pointage = getPointageById(id);
        pointage.setDatePointage(pointageDetails.getDatePointage());
        pointage.setOperations(pointageDetails.getOperations());
        pointage.setUser(pointageDetails.getUser());
        pointage.setPlanningUser(pointageDetails.getPlanningUser());
        pointage.calculerHeuresTravaillees(); // Recalculer les heures travaillées
        return pointageRepository.save(pointage);
    }

    // Supprimer un pointage par son ID
    public void deletePointage(Long id) {
        pointageRepository.deleteById(id);
    }
}